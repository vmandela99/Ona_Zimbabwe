app <- ShinyDriver$new("../../")
app$snapshotInit("mytest")

app$setInputs(stats = "4")
app$setInputs(stats = "5")
app$setInputs(stats = "6")
app$snapshot()
